import { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface TourStep {
  emoji: string;
  title: string;
  desc: string;
  targetId?: string;  // DOM element id to spotlight
  position?: 'above' | 'below' | 'center';
}

const TOUR_STEPS: TourStep[] = [
  {
    emoji: '🎯',
    title: 'Welcome to Lumiq!',
    desc: "This quick tour will show you everything in about 30 seconds. Let's go!",
    position: 'center',
  },
  {
    emoji: '📚',
    title: 'Your Subjects',
    desc: 'These are your exam subjects. Tap any subject to start practising past questions in Exam Mode or Practice Mode.',
    targetId: 'tour-subjects',
    position: 'below',
  },
  {
    emoji: '📷',
    title: 'Scan Your Notes',
    desc: 'Tap the Scan button to photograph your lecture notes. Our AI will instantly turn them into practice questions.',
    targetId: 'tour-nav-scan',
    position: 'above',
  },
  {
    emoji: '🏆',
    title: 'Leaderboard',
    desc: 'Compete with classmates! Your top scores appear here. Set your display name to show up on the board.',
    targetId: 'tour-nav-board',
    position: 'above',
  },
  {
    emoji: '💬',
    title: 'Class Chat',
    desc: 'Chat with fellow students in real-time. Ask questions, share tips, and motivate each other before exams.',
    targetId: 'tour-nav-chat',
    position: 'above',
  },
  {
    emoji: '📊',
    title: 'Your Progress',
    desc: 'Track progress, get an AI Study Prescription, predict your exam score, and download question PDFs — all in the More tab!',
    targetId: 'tour-nav-more',
    position: 'above',
  },
  {
    emoji: '✅',
    title: "You're ready!",
    desc: 'Start with any subject and aim for 70%+. The more you practise, the better your predictions get. Good luck!',
    position: 'center',
  },
];

interface SpotlightRect {
  top: number;
  left: number;
  width: number;
  height: number;
}

interface CardPos {
  top?: number;
  bottom?: number;
  left?: number;
  right?: number;
  transform?: string;
  arrowDir: 'top' | 'bottom' | 'none';
}

interface Props {
  onDone: () => void;
}

export default function TourOverlay({ onDone }: Props) {
  const [step, setStep] = useState(0);
  const [spotlight, setSpotlight] = useState<SpotlightRect | null>(null);
  const [cardPos, setCardPos] = useState<CardPos>({ arrowDir: 'none' });
  const cardRef = useRef<HTMLDivElement>(null);

  const current = TOUR_STEPS[step];

  const positionForStep = useCallback((s: TourStep) => {
    if (!s.targetId || s.position === 'center') {
      setSpotlight(null);
      setCardPos({ top: undefined, left: undefined, transform: 'translate(-50%, -50%)', arrowDir: 'none' });
      return;
    }
    const el = document.getElementById(s.targetId);
    if (!el) {
      setSpotlight(null);
      setCardPos({ arrowDir: 'none' });
      return;
    }
    const rect = el.getBoundingClientRect();
    const pad = 8;
    setSpotlight({ top: rect.top - pad, left: rect.left - pad, width: rect.width + pad * 2, height: rect.height + pad * 2 });

    const cardW = Math.min(300, window.innerWidth - 40);
    const leftPos = Math.max(20, Math.min(rect.left, window.innerWidth - cardW - 20));

    if (s.position === 'above') {
      const cardH = 220;
      const topPos = rect.top - cardH - 20;
      if (topPos > 10) {
        setCardPos({ top: topPos, left: leftPos, arrowDir: 'bottom' });
      } else {
        setCardPos({ top: rect.bottom + 16, left: leftPos, arrowDir: 'top' });
      }
    } else {
      setCardPos({ top: rect.bottom + 16, left: leftPos, arrowDir: 'top' });
    }
  }, []);

  useEffect(() => {
    positionForStep(current);
  }, [step, current, positionForStep]);

  const next = () => {
    if (step >= TOUR_STEPS.length - 1) { onDone(); return; }
    setStep(s => s + 1);
  };

  const isCenter = !current.targetId || current.position === 'center';
  const isLast = step === TOUR_STEPS.length - 1;

  return (
    <div className="fixed inset-0 z-[2000]" style={{ pointerEvents: 'all' }}>
      {/* Dark backdrop */}
      <div className="absolute inset-0" style={{ background: 'rgba(0,0,0,0.78)' }} onClick={next} />

      {/* Spotlight cutout */}
      <AnimatePresence>
        {spotlight && (
          <motion.div
            key="spotlight"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3, ease: [0.34, 1.2, 0.64, 1] }}
            className="absolute rounded-2xl pointer-events-none"
            style={{
              top: spotlight.top,
              left: spotlight.left,
              width: spotlight.width,
              height: spotlight.height,
              boxShadow: '0 0 0 9999px rgba(0,0,0,0.78)',
              border: '2px solid rgba(99,102,241,0.7)',
              zIndex: 2001,
            }}
          />
        )}
      </AnimatePresence>

      {/* Tour card */}
      <AnimatePresence mode="wait">
        <motion.div
          key={step}
          ref={cardRef}
          initial={{ opacity: 0, scale: 0.92, y: 6 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.94, y: -4 }}
          transition={{ duration: 0.28, ease: [0.34, 1.2, 0.64, 1] }}
          className="absolute pointer-events-auto"
          style={{
            zIndex: 2002,
            ...(isCenter
              ? { top: '50%', left: '50%', transform: 'translate(-50%, -50%)', width: 'calc(100vw - 40px)', maxWidth: 300 }
              : { top: cardPos.top, left: cardPos.left, width: Math.min(300, window.innerWidth - 40) }
            ),
          }}
        >
          {/* Arrow top */}
          {!isCenter && cardPos.arrowDir === 'top' && (
            <div style={{ position: 'absolute', top: -7, left: 24, width: 12, height: 12, background: 'rgba(6,8,18,0.98)', border: '1px solid rgba(99,102,241,0.35)', transform: 'rotate(45deg)', borderRight: 'none', borderBottom: 'none' }} />
          )}

          <div className="rounded-[20px] p-5" style={{ background: 'rgba(6,8,18,0.98)', backdropFilter: 'blur(30px)', border: '1px solid rgba(99,102,241,0.35)', boxShadow: '0 8px 40px rgba(0,0,0,0.6), 0 0 0 1px rgba(99,102,241,0.15)' }}>
            {/* Emoji */}
            <div className="w-11 h-11 rounded-2xl flex items-center justify-center mb-3 text-xl" style={{ background: 'rgba(99,102,241,0.12)', border: '1px solid rgba(99,102,241,0.2)' }}>
              {current.emoji}
            </div>

            {/* Text */}
            <div className="text-[16px] font-extrabold mb-1.5" style={{ color: '#fff' }}>{current.title}</div>
            <div className="text-[13px] mb-4" style={{ color: 'rgba(255,255,255,0.6)', lineHeight: 1.65 }}>{current.desc}</div>

            {/* Footer */}
            <div className="flex items-center justify-between gap-3">
              <button onClick={onDone} className="text-[12px] px-1" style={{ color: 'rgba(255,255,255,0.3)', background: 'none', border: 'none' }}>
                Skip tour
              </button>

              {/* Dots */}
              <div className="flex gap-1.5">
                {TOUR_STEPS.map((_, i) => (
                  <div
                    key={i}
                    className="rounded-full transition-all"
                    style={{
                      width: i === step ? 18 : 6,
                      height: 6,
                      borderRadius: i === step ? 3 : '50%',
                      background: i === step ? '#6366f1' : 'rgba(255,255,255,0.2)',
                    }}
                  />
                ))}
              </div>

              <button
                onClick={next}
                className="rounded-xl px-5 py-2.5 text-[13px] font-bold transition-all active:scale-95 flex-shrink-0"
                style={{ background: 'linear-gradient(135deg, #6366f1, #4f46e5)', color: '#fff', border: 'none' }}
              >
                {isLast ? "Let's go! 🎯" : 'Next →'}
              </button>
            </div>
          </div>

          {/* Arrow bottom */}
          {!isCenter && cardPos.arrowDir === 'bottom' && (
            <div style={{ position: 'absolute', bottom: -7, left: 24, width: 12, height: 12, background: 'rgba(6,8,18,0.98)', border: '1px solid rgba(99,102,241,0.35)', transform: 'rotate(45deg)', borderLeft: 'none', borderTop: 'none' }} />
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
