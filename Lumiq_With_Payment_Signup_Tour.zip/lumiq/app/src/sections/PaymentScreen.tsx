import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useApp } from '@/context/AppContext';

// Paystack inline JS global type
declare global {
  interface Window {
    PaystackPop: {
      setup: (options: {
        key: string;
        email: string;
        amount: number;
        currency: string;
        ref: string;
        metadata?: Record<string, unknown>;
        onClose: () => void;
        callback: (response: { reference: string }) => void;
      }) => { openIframe: () => void };
    };
  }
}

type PlanKey = 'monthly' | 'quarterly' | 'semester';
type AuthMode = 'subscribe' | 'signin';

const PAYSTACK_KEY = 'pk_live_4cbd08681fd59c5618bba470814f0dc678c9c0c2';

const PLANS: Record<PlanKey, {
  name: string;
  price: string;
  amountKobo: number;
  period: string;
  save?: string;
  color: string;
  badge?: string;
}> = {
  monthly: {
    name: 'Monthly',
    price: '₦2,500',
    amountKobo: 250000,
    period: '/ month',
    color: '#3b82f6',
  },
  quarterly: {
    name: 'Semester',
    price: '₦6,500',
    amountKobo: 650000,
    period: '/ semester',
    save: 'Save ₦1,000',
    color: '#a855f7',
    badge: 'Popular',
  },
  semester: {
    name: 'Full Year',
    price: '₦20,000',
    amountKobo: 2000000,
    period: '/ year',
    save: 'Save ₦10,000',
    color: '#10b981',
    badge: 'Best 💎',
  },
};

const FEATURES = [
  { icon: '📚', label: 'All subjects' },
  { icon: '⏱️', label: 'Exam & Practice mode' },
  { icon: '📈', label: 'Score tracking' },
  { icon: '💬', label: 'Class chat' },
  { icon: '📄', label: '5 PDF uploads/week' },
];

function genRef() {
  return 'LMQ-' + Date.now() + '-' + Math.random().toString(36).slice(2, 7).toUpperCase();
}

export default function PaymentScreen() {
  const { navigate, showToast } = useApp();
  const [mode, setMode] = useState<AuthMode>('subscribe');
  const [selectedPlan, setSelectedPlan] = useState<PlanKey>('monthly');
  const [email, setEmail] = useState('');
  const [emailError, setEmailError] = useState('');
  const [accessCode, setAccessCode] = useState('');
  const [codeError, setCodeError] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);
  const [isPaying, setIsPaying] = useState(false);

  const plan = PLANS[selectedPlan];

  const handlePay = () => {
    // Validate email
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setEmailError('Please enter a valid email address.');
      return;
    }
    setEmailError('');

    if (!window.PaystackPop) {
      showToast('Payment SDK not loaded. Please refresh.');
      return;
    }

    setIsPaying(true);

    const handler = window.PaystackPop.setup({
      key: PAYSTACK_KEY,
      email,
      amount: plan.amountKobo,
      currency: 'NGN',
      ref: genRef(),
      metadata: { plan: selectedPlan, app: 'lumiq' },
      onClose: () => {
        setIsPaying(false);
        showToast('Payment cancelled.');
      },
      callback: (response) => {
        setIsPaying(false);
        // Payment successful — unlock the app
        localStorage.setItem('lumiq_unlocked', '1');
        localStorage.setItem('lumiq_plan', selectedPlan);
        localStorage.setItem('lumiq_paystack_ref', response.reference);
        navigate('schoolSetup');
        showToast('Payment successful! Welcome to Lumiq 🎉');
      },
    });

    handler.openIframe();
  };

  const handleFreeTrial = () => {
    localStorage.setItem('lumiq_unlocked', '1');
    navigate('schoolSetup');
    showToast('24-hour free trial started! 🎉');
  };

  const formatCode = (val: string) => {
    const clean = val.replace(/[^A-Za-z0-9]/g, '').toUpperCase().slice(0, 16);
    return clean.match(/.{1,4}/g)?.join('-') ?? clean;
  };

  const handleSignIn = async () => {
    if (accessCode.replace(/-/g, '').length < 16) {
      setCodeError('Please enter a valid 16-character access code.');
      return;
    }
    setIsVerifying(true);
    setCodeError('');
    await new Promise(r => setTimeout(r, 1200));
    setIsVerifying(false);
    localStorage.setItem('lumiq_unlocked', '1');
    navigate('schoolSetup');
    showToast('Signed in successfully!');
  };

  return (
    <motion.div
      className="fixed inset-0 z-[600] flex flex-col items-center justify-center overflow-y-auto"
      style={{ background: '#04060f' }}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
    >
      {/* Ambient orbs */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <div style={{ position: 'absolute', top: '-10%', left: '-10%', width: '60%', height: '60%', background: 'radial-gradient(circle, rgba(99,102,241,0.18) 0%, transparent 70%)', filter: 'blur(40px)' }} />
        <div style={{ position: 'absolute', bottom: '-10%', right: '-10%', width: '60%', height: '60%', background: 'radial-gradient(circle, rgba(168,85,247,0.14) 0%, transparent 70%)', filter: 'blur(40px)' }} />
      </div>

      <div className="relative w-full max-w-[400px] mx-auto px-5 py-10">
        {/* Logo */}
        <div className="flex flex-col items-center mb-8">
          <div className="w-14 h-14 rounded-2xl flex items-center justify-center mb-4" style={{ background: 'rgba(99,102,241,0.15)', border: '1px solid rgba(99,102,241,0.3)' }}>
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#818cf8" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="10" /><circle cx="12" cy="12" r="6" /><circle cx="12" cy="12" r="2" />
            </svg>
          </div>
          <div className="text-2xl font-extrabold tracking-tight" style={{ color: '#fff', letterSpacing: '-0.03em' }}>LUMIQ</div>
          <div className="text-[13px] mt-1" style={{ color: 'rgba(255,255,255,0.4)' }}>CBT Practice for Nigerian Students</div>
        </div>

        {/* Auth toggle */}
        <div className="flex gap-1.5 rounded-xl p-1 mb-6" style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)' }}>
          {(['subscribe', 'signin'] as const).map(m => (
            <button
              key={m}
              onClick={() => setMode(m)}
              className="flex-1 py-2.5 rounded-[10px] text-[13px] font-bold transition-all flex items-center justify-center gap-1.5"
              style={{
                background: mode === m ? 'rgba(99,102,241,0.25)' : 'transparent',
                color: mode === m ? '#a5b4fc' : 'rgba(255,255,255,0.4)',
                border: mode === m ? '1px solid rgba(99,102,241,0.4)' : '1px solid transparent',
              }}
            >
              {m === 'subscribe' ? (
                <><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><rect x="1" y="4" width="22" height="16" rx="2" /><line x1="1" y1="10" x2="23" y2="10" /></svg>Subscribe</>
              ) : (
                <><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" /><path d="M7 11V7a5 5 0 0 1 10 0v4" /></svg>Sign In</>
              )}
            </button>
          ))}
        </div>

        <AnimatePresence mode="wait">
          {mode === 'subscribe' ? (
            <motion.div key="subscribe" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.15 }}>

              {/* Plan tabs */}
              <div className="grid grid-cols-3 gap-2 mb-4">
                {(Object.entries(PLANS) as [PlanKey, typeof PLANS[PlanKey]][]).map(([key, p]) => (
                  <button
                    key={key}
                    onClick={() => setSelectedPlan(key)}
                    className="relative rounded-2xl p-3 pb-2.5 text-center transition-all"
                    style={{
                      background: selectedPlan === key
                        ? `rgba(${key === 'monthly' ? '59,130,246' : key === 'quarterly' ? '168,85,247' : '16,185,129'},0.12)`
                        : 'rgba(255,255,255,0.05)',
                      border: selectedPlan === key ? `1.5px solid ${p.color}80` : '1.5px solid rgba(255,255,255,0.1)',
                      boxShadow: selectedPlan === key ? `0 0 0 1px ${p.color}30, 0 4px 20px ${p.color}20` : 'none',
                    }}
                  >
                    {p.badge && (
                      <div className="absolute -top-2.5 left-1/2 -translate-x-1/2 text-[8px] font-extrabold uppercase tracking-widest px-2 py-0.5 rounded-full whitespace-nowrap" style={{ background: p.color, color: '#fff' }}>
                        {p.badge}
                      </div>
                    )}
                    <div className="text-[10px] font-bold uppercase tracking-widest mb-1" style={{ color: selectedPlan === key ? p.color : 'rgba(255,255,255,0.4)' }}>{p.name}</div>
                    <div className="text-[15px] font-extrabold" style={{ color: '#fff', letterSpacing: '-0.02em' }}>{p.price}</div>
                    <div className="text-[9px] mt-0.5" style={{ color: 'rgba(255,255,255,0.3)' }}>{p.period.replace('/ ', '')}</div>
                  </button>
                ))}
              </div>

              {/* Detail panel */}
              <div className="rounded-2xl p-4 mb-4" style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.1)' }}>
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <span className="text-2xl font-extrabold" style={{ color: '#fff', letterSpacing: '-0.03em' }}>{plan.price}</span>
                    <span className="text-xs ml-1.5" style={{ color: 'rgba(255,255,255,0.4)' }}>{plan.period}</span>
                  </div>
                  {plan.save && (
                    <div className="text-[11px] font-bold px-3 py-1 rounded-full" style={{ background: `${plan.color}18`, border: `1px solid ${plan.color}40`, color: plan.color }}>
                      {plan.save}
                    </div>
                  )}
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {FEATURES.map(f => (
                    <div key={f.label} className="flex items-center gap-1.5 text-[11px] font-medium px-2.5 py-1.5 rounded-xl" style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', color: 'rgba(255,255,255,0.7)' }}>
                      <span>{f.icon}</span>{f.label}
                    </div>
                  ))}
                </div>
              </div>

              {/* Email input */}
              <div className="mb-3">
                <input
                  type="email"
                  value={email}
                  onChange={e => { setEmail(e.target.value); setEmailError(''); }}
                  placeholder="your@email.com"
                  className="w-full rounded-xl px-4 py-3.5 text-[14px] outline-none"
                  style={{
                    background: 'rgba(255,255,255,0.07)',
                    border: `1.5px solid ${emailError ? 'rgba(239,68,68,0.6)' : 'rgba(255,255,255,0.15)'}`,
                    color: '#fff',
                    caretColor: '#818cf8',
                  }}
                  onKeyDown={e => e.key === 'Enter' && handlePay()}
                />
                {emailError && <p className="text-xs mt-1.5 ml-1" style={{ color: '#f87171' }}>{emailError}</p>}
              </div>

              {/* Pay button */}
              <button
                onClick={handlePay}
                disabled={isPaying}
                className="w-full py-5 rounded-2xl text-[17px] font-extrabold flex items-center justify-center gap-2 mb-3 transition-all active:scale-[0.98] disabled:opacity-60"
                style={{ background: 'linear-gradient(135deg, #0ea5e9, #0284c7)', color: '#fff', boxShadow: '0 6px 28px rgba(14,165,233,0.4), inset 0 1px 0 rgba(255,255,255,0.25)', letterSpacing: '0.01em' }}
              >
                {isPaying ? (
                  <svg className="animate-spin" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><circle cx="12" cy="12" r="10" strokeOpacity="0.25" /><path d="M12 2a10 10 0 0 1 10 10" /></svg>
                ) : (
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><rect x="1" y="4" width="22" height="16" rx="2" /><line x1="1" y1="10" x2="23" y2="10" /></svg>
                )}
                {isPaying ? 'Opening Paystack...' : `Pay ${plan.price} — ${plan.name}`}
              </button>

              {/* Free trial */}
              <button
                onClick={handleFreeTrial}
                className="w-full py-3 text-[13px] font-semibold flex items-center justify-center gap-2 transition-all"
                style={{ color: 'rgba(255,255,255,0.45)' }}
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10" /><polyline points="12 6 12 12 16 14" /></svg>
                Try Free for 24 Hours — No Card Needed
              </button>
            </motion.div>
          ) : (
            <motion.div key="signin" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.15 }}>
              <p className="text-[13px] text-center mb-5" style={{ color: 'rgba(255,255,255,0.45)', lineHeight: 1.6 }}>
                Enter your access code to<br />sign in on this device
              </p>
              <input
                type="text"
                value={accessCode}
                onChange={e => { setAccessCode(formatCode(e.target.value)); setCodeError(''); }}
                placeholder="XXXX-XXXX-XXXX-XXXX"
                maxLength={19}
                className="w-full rounded-xl px-4 py-4 text-center text-[17px] font-bold tracking-widest outline-none mb-2 uppercase"
                style={{ background: 'rgba(255,255,255,0.07)', border: `1.5px solid ${codeError ? 'rgba(239,68,68,0.6)' : 'rgba(255,255,255,0.2)'}`, color: '#fff', caretColor: '#818cf8' }}
                onKeyDown={e => e.key === 'Enter' && handleSignIn()}
              />
              {codeError && <p className="text-xs mb-3 text-center" style={{ color: '#f87171' }}>{codeError}</p>}
              <button
                onClick={handleSignIn}
                disabled={isVerifying}
                className="w-full py-5 rounded-2xl text-[17px] font-extrabold flex items-center justify-center gap-2 mt-2 transition-all active:scale-[0.98] disabled:opacity-60"
                style={{ background: 'linear-gradient(135deg, #6366f1, #4f46e5)', color: '#fff', boxShadow: '0 6px 28px rgba(99,102,241,0.4)' }}
              >
                {isVerifying ? (
                  <svg className="animate-spin" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><circle cx="12" cy="12" r="10" strokeOpacity="0.25" /><path d="M12 2a10 10 0 0 1 10 10" /></svg>
                ) : (
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" /><path d="M7 11V7a5 5 0 0 1 10 0v4" /></svg>
                )}
                {isVerifying ? 'Verifying...' : 'Sign In →'}
              </button>
              <p className="text-center mt-4 text-xs" style={{ color: 'rgba(255,255,255,0.25)' }}>
                No code yet?{' '}
                <button onClick={() => setMode('subscribe')} className="underline" style={{ color: 'rgba(255,255,255,0.45)' }}>Switch to Subscribe above</button>
              </p>
            </motion.div>
          )}
        </AnimatePresence>

        <p className="text-center text-[11px] mt-6" style={{ color: 'rgba(255,255,255,0.2)' }}>Built by Shant 🇳🇬</p>
      </div>
    </motion.div>
  );
}
