# Lumiq — Tech Spec

## Component Inventory

### shadcn/ui Components (Built-in)
| Component | Purpose |
|-----------|---------|
| Button | Primary, ghost, danger variants throughout |
| Card | All card surfaces (hero, stats, subjects, settings) |
| Input | Text inputs for profile, search, chat |
| Dialog | Modal overlays (profile edit, create course) |
| Sheet | Bottom sheet modals |
| Accordion | FAQ items, department expandables |
| Progress | Progress bars for course coverage |
| ScrollArea | Chat messages, leaderboard lists |
| Separator | Visual dividers |
| Badge | Level pills, status indicators |
| Avatar | Profile initials avatar |
| Tooltip | Icon button hints |
| Switch | Toggle settings |

### Custom Components
| Component | Purpose | Props |
|-----------|---------|-------|
| AppShell | Top bar + nav + page router | children, currentPage |
| TopBar | Sticky header with logo + badge | userName, onThemeToggle |
| BottomNav | 5-item frosted glass nav | activePage, onNavigate |
| GlassCard | Reusable glassmorphic card | children, className, onClick |
| StatBox | Stat display with count-up | value, label, color |
| SubjectCard | Course selection card | subject, icon, count, onClick |
| OptionButton | MCQ option with states | label, text, state, onClick |
| ScoreRing | Circular score display | score, size |
| ProgressBar | Animated progress bar | value, max, color |
| TimerPill | Exam countdown timer | seconds, warning |
| QuestionDots | Navigation dot grid | total, current, answered |
| StreakPill | Streak display badge | current, best |
| ExamRecord | History list item | record |
| WeakAreaItem | Weak area display | subject, pct, count |
| CourseProgressItem | Progress tracking | subject, covered, avg, attempts |
| CollapsibleSection | Expandable card section | title, icon, defaultOpen |
| QuotaPill | Upload quota indicator | used, max |
| LoadingSpinner | Animated spinner | size, color |
| Toast | Toast notification | message, visible |
| PageTransition | Page switch wrapper | children, pageKey |
| AmbientOrbs | Background decoration | - |
| IconBadge | SVG/emoji icon container | icon, size, tinted |
| ReferralCard | Referral code display | code, onCopy, onClaim |
| FeatureLock | Premium feature placeholder | featureName, planRequired |
| ProfileCard | Student profile display | profile, onEdit, onChangeSchool |
| CreateCourseModal | Course creation form | onSave, onClose |
| ProfileEditModal | Profile edit form | profile, onSave, onClose |
| SchoolSetup | Multi-step school wizard | onComplete, onClose |
| ScanOverlay | PDF/photo scan flow | onClose |
| AITutorOverlay | Chat tutor interface | onClose, context |

## Animation Implementation Table

| Animation | Library | Implementation Approach | Complexity |
|-----------|---------|------------------------|------------|
| Page transitions (fade in/out) | Framer Motion | AnimatePresence + motion.div with opacity variants | Low |
| Card press (scale 0.97) | Framer Motion | whileTap={{ scale: 0.97 }} with spring transition | Low |
| Modal slide-up | Framer Motion | motion.div initial={{ y: "100%" }} animate={{ y: 0 }} | Medium |
| Collapsible sections | Framer Motion | animate={{ height: "auto" }} with overflow hidden | Medium |
| Progress bar fill | CSS | transition: width 0.5s ease | Low |
| Score ring stroke | CSS + SVG | stroke-dashoffset animation, 1s ease | Medium |
| Timer pulse warning | CSS | @keyframes pulse with opacity | Low |
| Streak float | CSS | @keyframes float with translateY | Low |
| Loading spinner | CSS | @keyframes spin, rotate 360deg | Low |
| Nav active indicator | Framer Motion | layoutId for sliding background indicator | Medium |
| Button press | Framer Motion | whileTap={{ scale: 0.96 }} | Low |
| Option select states | CSS | transition on background-color, border-color | Low |
| Explanation slide-down | Framer Motion | animate={{ height: "auto", opacity: 1 }} | Medium |
| Auto-advance question | Framer Motion | AnimatePresence with slideLeft/slideRight | Medium |
| Toast fade | Framer Motion | animate={{ opacity: [0, 1, 1, 0] }} with delay | Low |
| Count-up stats | Custom hook | useCountUp with requestAnimationFrame | Low |
| Ambient orbs drift | CSS | @keyframes drift with translate, very slow | Low |
| Course icon picker select | Framer Motion | whileTap={{ scale: 1.12 }} | Low |
| School setup step transition | Framer Motion | AnimatePresence with slide direction | Medium |
| Scan loading stages | CSS | Cycling text with setInterval + CSS transitions | Low |
| Referral copy feedback | Framer Motion | scale pulse on button | Low |

## State & Logic Plan

### Global State (React Context + useReducer)

**AppContext** manages:
- `page`: current active page string
- `courses`: loaded course data array
- `profile`: student profile object
- `history`: exam records array
- `streak`: streak info object
- `leaderboard`: leaderboard entries record
- `theme`: current theme mode
- `examDate`: exam countdown date
- `settings`: app settings object
- `scanState`: PDF scan workflow state
- `chatMessages`: chat message array
- `toast`: current toast message

All state persisted to localStorage via useEffect hooks. Key prefix: `lumiq_`.

### Page Router
Simple state-based router in AppContext:
- Pages: home, subject, exam, results, board, chat, more, scan, tutor, schoolSetup
- Navigation function updates `page` state
- AppShell renders appropriate page component based on `page`

### Core Hooks

| Hook | Purpose |
|------|---------|
| useLocalStorage | Sync state with localStorage |
| useCountUp | Animate number counting |
| useTimer | Exam countdown timer |
| useStreak | Track and update study streaks |
| useTheme | Apply theme class to body, persist preference |
| useToast | Show/dismiss toast notifications |
| useSchoolSetup | Multi-step wizard state machine |
| useScanFlow | PDF scan workflow state machine |
| useExamEngine | Question flow, scoring, results |

### Data Flow

**Course Loading:**
- Static demo data seeded on first load
- Courses stored in context + localStorage
- Custom courses merged with built-in courses

**Exam Flow:**
1. User selects subject → subject index stored in context
2. User selects count + mode → exam state initialized with shuffled questions
3. User answers → answers array updated
4. Submit → results calculated, history saved, streak updated, leaderboard updated
5. Results displayed → option to retry, review, or go home

**Profile Flow:**
1. Profile stored in context + localStorage
2. Edit modal opens with current values
3. Save updates context → re-persists → updates UI

**Theme Flow:**
1. Theme stored in context + localStorage
2. useTheme applies class to body on mount and change
3. All themed components use CSS custom properties or conditional classes

## Other Key Decisions

### Icon Strategy
- Lucide React for all UI icons (home, board, chat, settings, etc.)
- Emoji for subject/course icons (📚, 🔬, 💻, etc.)
- Custom SVG for Lumiq logo (target/crosshair design)

### Mobile-First Approach
- Single column layout
- Max-width 600px centered on larger screens
- Touch-friendly targets (min 44px)
- Bottom sheet modals instead of centered dialogs
- Safe area inset support via CSS env()

### PWA Considerations
- Service worker for offline support
- localStorage for data persistence
- All assets inlined or bundled
- Responsive meta viewport tag

### Performance
- Lazy load page components via React.lazy
- Memoize expensive calculations (history analysis, predictions)
- useMemo for filtered/sorted lists
- Virtual scrolling for long lists (chat, leaderboard, history)
